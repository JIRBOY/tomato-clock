#pragma once

#include <SDKDDKVer.h>

#define WINVER 0x0A00
#define _WIN32_WINNT 0x0A00
#define _WIN32_WINDOWS 0x0A00
#define _WIN32_IE 0x0A00