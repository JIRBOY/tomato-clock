# CLAUDE.md

## Project Overview

一个简单的番茄钟程序，只显示一个总在最前的小窗口，用于显示倒计时，当倒计时到达50分钟时闪烁并蜂鸣1分钟，等待5分钟后继续倒计时。

## 技术栈

- 基于Visual Studio 2019 的静态MFC库

## 工作流
1. 检查Visual Studio 2019是否可用。
2. 生成Visual Studio 2019版的C++版桌面Windows程序MFC应用的工程文件，名称“TomatoClock”
3. 新建一个窗口，不显示标题栏，大小为高20像素宽100像素
4. 先做这些，其它我们交互完成。
